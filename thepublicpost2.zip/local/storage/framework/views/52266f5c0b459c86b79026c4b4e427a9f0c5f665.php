<?php $__env->startSection('title'); ?>
    New Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-3 col-md-6">
            	<?php echo Form::open(['route' => 'admin.categories.store','method' => 'POST']); ?>


            		<div class="form-group">
            			<?php echo Form::label('name','Name'); ?>

            			<?php echo Form::text('name', null,['class'=> 'form-control','placeholder'=>'Type a name for the category','required']); ?>

            		</div>
            		<div class="form-group">
            			<?php echo Form::submit('Add Category',['class'=>'btn btn-primary']); ?>

            		</div>

            	<?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>