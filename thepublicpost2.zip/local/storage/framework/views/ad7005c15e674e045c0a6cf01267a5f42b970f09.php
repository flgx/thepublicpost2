<?php $__env->startSection('title','Edit User: '. $user->name); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="actions col-xs-12">
                    <a class="btn btn-primary" href="<?php echo e(url('admin/posts/'.$user->id.'/user')); ?>"><i class="fa fa-archive"></i> User Posts</a>
                    <a class="btn btn-primary" href="<?php echo e(url('admin/photos/'.$user->id.'/user')); ?>"><i class="fa fa-photo"></i> User Photos</a>
                    <a class="btn btn-primary" href="<?php echo e(url('admin/videos/'.$user->id.'/user')); ?>"><i class="fa fa-video-camera"></i> User Videos</a>
                    <a class="btn btn-primary" href="<?php echo e(url('admin/ebooks/'.$user->id.'/user')); ?>"><i class="fa fa-book"></i> User Ebooks</a>
                </div>
                <hr>
            	<?php echo Form::open(['route' => ['admin.users.update',$user->id],'method' => 'PUT','files' => true]); ?>

                    <?php if($user->profile_image): ?>
                    <div class="col-xs-6">
                        <?php if(Auth::user()->profile_image && Auth::user()->facebook_id == 'null'): ?>
                        
                          <img src="<?php echo e(asset('img/users/profile').'/profile_'.Auth::user()->profile_image); ?>" class="img-circle col-xs-12" alt="The Post Page ">
                        <?php elseif(Auth::user()->facebook_id != 'null'): ?>          
                          <img src="<?php echo e(Auth::user()->profile_image); ?>" class="img-circle" alt="The Post Page ">
                        <?php else: ?>
                         <img src="asset('img/profile.png')" class="img-circle" alt="The Post Page ">
                        <?php endif; ?>                        
                     </div>
                    <?php else: ?>
                    <div class="col-xs-6">
                        <img src="<?php echo e(asset('img/profile.png')); ?>" class="img-circle " alt="The Post Page ">   
                        <div class="panel panel-success">
                          <div class="panel-heading">* Please change your profile image.</div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="form-group col-xs-6">
                        <?php echo Form::label('profile_image','Profile Image'); ?>

                        <?php echo Form::file('profile_image',null,['class'=> 'form-control','required']); ?>


                    </div>                
            		<div class="form-group col-xs-12">
            			<?php echo Form::label('name','Name'); ?>

            			<?php echo Form::text('name', $user->name,['class'=> 'form-control','placeholder'=>'Type a name','required']); ?>

            		</div>
            		<div class="form-group col-xs-12">
            			<?php echo Form::label('email','E-mail'); ?>

            			<?php echo Form::email('email', $user->email,['class'=> 'form-control','placeholder'=>'youremail@gmail.com','required']); ?>

            		</div>
                        
                    <div class="form-group col-xs-12">
                        <?php echo Form::label('bkash','Bkash'); ?>

                        <?php echo Form::text('bkash', $user->bkash,['class'=> 'form-control','placeholder'=>'Type your bkash ID','required']); ?>

                    </div>

                    <?php if(Auth::user()->type == 'admin'): ?>
            		<div class="form-group col-xs-12">
            			<?php echo Form::label('type','User Type'); ?>

            			<?php echo Form::select('type',[''=>'Select type of user','member'=> 'Member','admin' => 'Administrator'],$user->type,['class'=> 'form-control','required']); ?>

            		</div>
                    <?php endif; ?>
            		<div class="form-group col-xs-12">
            			<?php echo Form::submit('Edit User',['class'=>'btn btn-primary']); ?>

            		</div>

            	<?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>