    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container" style="padding:0">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="logo">
                <a href="#" class="navbar-left"><img class="img-responsive" src="{{asset('img/Logo.png')}}" alt="logo"></a>
                </div>
                <!---<a class="navbar-brand" href="#">Start Bootstrap</a>-->
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse main-menu" id="bs-example-navbar-collapse-1">
                <div class="ul">
                <ul class="nav navbar-nav">
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#1</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#2</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#3</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#4</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#5</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#6</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#7</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#8</a>
                    </li>
                    <li class="li-items" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#9</a>
                    </li>
                    <li class="li-items2" style="height:100%">
                        <a href="#" style="line-height:65px;padding:0px 10px;color:white; text-decoration:none">Item#10</a>
                    </li>
                    <li style="height:100%" class="login">
                    <a href="{{url('/login')}}" style="line-height:65px;padding:0px 10px;color:white" class="register pull-right">sign in / sign up</a>
                    </li>
                </ul>
                </div>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>